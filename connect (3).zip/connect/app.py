from flask import Flask, render_template, request, redirect, url_for, g, flash, session
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from email_validator import validate_email, EmailNotValidError

app = Flask(__name__)
app.static_folder = 'static'
app.config['SECRET_KEY'] = 'Diary1234'
DATABASE = 'mydatabase.db'

# Database initialization
def init_db():
    with sqlite3.connect(DATABASE) as db:
        cursor = db.cursor()
        with app.open_resource('schema.sql', mode='r') as f:
            cursor.executescript(f.read())
        db.commit()

init_db()

# Helper function to get the database connection
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db
# Varshini
# Helper function to get user-specific titles
# Helper function to get user-specific titles
def get_user_data(user_id):
    with get_db() as db:
        cursor = db.cursor()

        # Fetch user details
        cursor.execute('SELECT * FROM users WHERE id = ?', [user_id])
        user_data = cursor.fetchone()

        # Fetch user-specific titles with details
        user_titles = []
        tables = ['articles','story','travel','poem']  # Add more tables as needed

        for table in tables:
            cursor.execute(f'SELECT * FROM {table} WHERE user_id = ?', [user_id])
            entries = cursor.fetchall()
            user_titles.extend([(entry['id'], entry['title'], table, entry) for entry in entries])

        return user_data, user_titles


def get_entry_details(table, title):
    with sqlite3.connect(DATABASE) as db:
        cursor = db.cursor()
        cursor.execute(f'SELECT * FROM {table} WHERE title = ?', [title])
        entry_details = cursor.fetchone()
        return entry_details
# Home route
@app.route('/')
def index():
    return render_template('index.html')

# Login route


# Signup route

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        db = get_db()
        cursor = db.execute('SELECT * FROM users WHERE username = ?', [username])
        user = cursor.fetchone()

        if user and check_password_hash(user['password'], password):
            flash('Login successful', 'success')
            session['logged_in'] = True
            session['user_id'] = user['id']  # Store user ID in the session
            return redirect(url_for('template_d'))
        else:
            flash('Invalid username or password. Please try again.', 'error')

    return render_template('login.html')

# Signup route
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        # Check if password and confirm password match
        if password != confirm_password:
            flash('Password and confirm password do not match.', 'error')
            return redirect(url_for('signup'))

        # Check if password has a minimum length of 6 characters
        if len(password) < 6:
            flash('Password must be at least 6 characters long.', 'error')
            return redirect(url_for('signup'))

        try:
            # Validate email address
            v = validate_email(email)
            email = v.email

            # Separate connection for writing operations
            with sqlite3.connect(DATABASE) as db:
                db.row_factory = sqlite3.Row
                cursor = db.cursor()

                # Check if the username already exists
                existing_user = cursor.execute('SELECT * FROM users WHERE username = ?', [username]).fetchone()
                if existing_user:
                    flash('Username already exists. Please choose a different username.', 'error')
                    return redirect(url_for('signup'))

                # Check if the email already exists
                existing_email = cursor.execute('SELECT * FROM users WHERE email = ?', [email]).fetchone()
                if existing_email:
                    flash('Email already exists. Please use a different email.', 'error')
                    return redirect(url_for('signup'))

                # Insert new user into the "users" table
                cursor.execute('INSERT INTO users (first_name, last_name, email, username, password) VALUES (?, ?, ?, ?, ?)',
                               [first_name, last_name, email, username, generate_password_hash(password)])
                db.commit()

            flash('Signup successful. You can now log in.', 'success')
            return redirect(url_for('login'))

        except EmailNotValidError as e:
            flash(f'Invalid email address: {str(e)}', 'error')
            return redirect(url_for('signup'))
        except Exception as e:
            flash(f'Error during signup: {str(e)}', 'error')
            return redirect(url_for('signup'))

    return render_template('signup.html')

# Template D route
#Srinidhi

# Template D route
@app.route('/template_d', methods=['GET', 'POST'])
def template_d():
    if 'logged_in' in session and session['logged_in']:
        user_id = session.get('user_id')
        user_data, user_titles = get_user_data(user_id)

        if request.method == 'POST':
            selected_category = request.form.get('category')
            if selected_category:
                return redirect(url_for(selected_category))
            else:
                flash('Invalid category selection.', 'error')

        # Pass the get_entry_details function explicitly
        return render_template('d.html', user_data=user_data, user_titles=user_titles, get_entry_details=get_entry_details)

    flash('You need to log in first.', 'error')
    return redirect(url_for('login'))

# Article route
@app.route('/articles', methods=['GET', 'POST'])
def articles():
    if request.method == 'POST':
        date = request.form['date']
        genre = request.form['genre']
        title = request.form['title']
        description = request.form['description']
        
        user_id = session.get('user_id')

        # Perform database update
        with sqlite3.connect(DATABASE) as db:
            cursor = db.cursor()
            cursor.execute(
                'INSERT INTO articles (user_id, date, genre, title, description) VALUES (?, ?, ?, ?, ?)',
                [user_id, date, genre, title, description]
            )
            db.commit()
        # Your article submission logic here
        return redirect(url_for('template_d'))

    return render_template('articles.html')

# Story route
@app.route('/story', methods=['GET', 'POST'])
def story():
    if request.method == 'POST':
        date = request.form['date']
        genre = request.form['genre']
        title = request.form['title']
        description = request.form['description']
        
        user_id = session.get('user_id')

        # Perform database update
        with sqlite3.connect(DATABASE) as db:
            cursor = db.cursor()
            cursor.execute(
                'INSERT INTO story(user_id, date, genre, title, description) VALUES (?, ?, ?, ?, ?)',
                [user_id, date, genre, title, description]
            )
            db.commit()
        return redirect(url_for('template_d'))

    return render_template('story.html')

# Travel route
@app.route('/travel',methods=['GET', 'POST'])
def travel():
    if request.method == 'POST':
        date = request.form['date']
        location = request.form['location']
        title = request.form['title']
        description = request.form['description']
        
        user_id = session.get('user_id')

        # Perform database update
        with sqlite3.connect(DATABASE) as db:
            cursor = db.cursor()
            cursor.execute(
                'INSERT INTO travel(user_id, date, location, title, description) VALUES (?, ?, ?, ?, ?)',
                [user_id, date, location, title, description]
            )
            db.commit()
        # Your article submission logic here
        return redirect(url_for('template_d'))
    return render_template('travel.html')

    
    
         
    

   

# Work route


# Poem route
@app.route('/poem',methods=['GET', 'POST'])
def poem():
    if request.method == 'POST':
        date = request.form['date']
        genre = request.form['genre']
        title = request.form['title']
        description = request.form['description']
        
        user_id = session.get('user_id')

        # Perform database update
        with sqlite3.connect(DATABASE) as db:
            cursor = db.cursor()
            cursor.execute(
                'INSERT INTO poem(user_id, date, genre, title, description) VALUES (?, ?, ?, ?, ?)',
                [user_id, date, genre, title, description]
            )
            db.commit()
        return redirect(url_for('template_d'))

    return render_template('poem.html')

# Schedule route


# View entry route

if __name__ == '__main__':
    app.run(debug=True)
